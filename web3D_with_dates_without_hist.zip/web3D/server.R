library(shiny)
library(datasets)

# Define server logic required to plot various count against coloumnsZA
shinyServer(function(input, output) {
  
  xG <- reactive({
    switch(input$xColoumn, setFromAndToDates(input$fromToDates[1], input$fromToDates[2]))
	switch(input$xColoumn, getTwoDimensionalMatrixFromElasticsearch(input$xColoumn))
  })
  
  yG <- reactive({
    switch(input$xColoumn, setFromAndToDates(input$fromToDates[1], input$fromToDates[2]))
    switch(input$yColoumn, getTwoDimensionalMatrixFromElasticsearch(input$yColoumn) )
  })
  
  xsysMatrix <- reactive({
	switch(input$xColoumn, getXYsMatrixFromElasticsearch(xG(), yG(), input$xColoumn, input$yColoumn))
	switch(input$yColoumn, getXYsMatrixFromElasticsearch(xG(), yG(), input$xColoumn, input$yColoumn))
  })
  
  ysxsMatrix <- reactive({
	switch(input$xColoumn, getXYsMatrixFromElasticsearch(yG(), xG(), input$yColoumn, input$xColoumn))
	switch(input$yColoumn, getXYsMatrixFromElasticsearch(yG(), xG(), input$yColoumn, input$xColoumn))
  })
  
  xsMatrixForFixY <- reactive({
	switch(input$fixY, if(input$fixY %in% yG()[,1]) getXsMatrixFromElasticsearch(input$fixY, input$xColoumn, input$yColoumn) )
  })
  
  xsCFLTopMatrixForFixY <- reactive({
	switch(input$fixY, if(input$fixY %in% yG()[,1]) getXYsMatrixFromElasticsearch(xG(), fixY, input$xColoumn, input$yColoumn) )
  })
  
  graphType <- reactive({
	switch(input$graphType, if(input$graphType == 'bar') TRUE else FALSE )
  })
  
  output$xGTable <- renderTable({
    head(xG())
  })
  
  output$yGTable <- renderTable({
    head(yG())
  })
  
  output$xsysTable <- renderTable({
    head(xsysMatrix())
  })
  
  output$ysxsTable <- renderTable({
    head(ysxsMatrix())
  })

  output$ownTopXsForFixYTable <- renderTable({
    head(xsMatrixForFixY())
  })
  
  output$cflTopXsForFixYTable <- renderTable({
    head(xsCFLTopMatrixForFixY())
  })
  
  output$xG <- renderPlot({
	xG <- xG()	
	barplot(as.numeric(xG[,2]), main=input$xColoumn, xlab=input$xColoumn, ylab="Count", names.arg=paste(xG[,1]), col=rainbow(rainbowColor) )
    legend("topright", legend=paste(xG[,1]), fill=rainbow(rainbowColor))
  })
  
  output$yG <- renderPlot({
	yG <- yG()
	barplot(as.numeric(yG[,2]), main=input$yColoumn, xlab=input$yColoumn, ylab="Count", names.arg=paste(yG[,1]), col=rainbow(rainbowColor) )
    legend("topright", legend=paste(yG[,1]), fill=rainbow(rainbowColor))
  })
  
  output$xsys <- renderPlot({
	xG <- xG()
	yG <- yG()
	barplot(xsysMatrix(), main=paste(input$xColoumn, "s"," vs ", input$yColoumn, "s", sep=""), xlab= input$xColoumn, ylab= "Count", beside=graphType(), names.arg=xG[,1], col=rainbow(rainbowColor))
	legend("topright", legend=paste(yG[,1]), fill=rainbow(rainbowColor)) 
  })
  
  output$flip_xsys <- renderPlot({
	xG <- xG()
	yG <- yG()	
	barplot(ysxsMatrix(), main=paste(input$yColoumn, "s"," vs ", input$xColoumn, "s", sep=""), xlab= input$yColoumn, ylab= "Count", beside=graphType(), names.arg=yG[,1], col=rainbow(rainbowColor))
	legend("topright", legend=paste(xG[,1]), fill=rainbow(rainbowColor)) 
  })
  
  output$ownTopXsForFixY <- renderPlot({
	if(length(xsMatrixForFixY()[2,]) != 0) {
		xG <- xG()
		yG <- yG()
		barplot(as.numeric(xsMatrixForFixY()[2,]), main=paste(xColoumnG,"vs", yColoumnG,fixY), xlab= xColoumnG, ylab= "Count", names.arg=xsMatrixForFixY()[1,], col=rainbow(rainbowColor))
		legend("topright", legend=paste(xsMatrixForFixY()[1,]), fill=rainbow(rainbowColor))
	}	
  })
  
  output$cflTopXsForFixY <- renderPlot({
	if(length(xsCFLTopMatrixForFixY()[1,]) != 0) {
		xG <- xG()
		yG <- yG()
		barplot(as.numeric(xsCFLTopMatrixForFixY()[1,]), main=paste(xColoumnG,"vs", yColoumnG,fixY), xlab= xColoumnG, ylab= "Count", names.arg=paste(xG()[,1]), col=rainbow(rainbowColor))
		legend("topright", legend=paste(xG()[,1]), fill=rainbow(rainbowColor))
	}	
  })
  
  output$histogram <- renderPlot({
	xG <- xG()
	barplot(as.numeric(xG[,2]), main=input$xColoumn, xlab=input$xColoumn, ylab="Count", names.arg=paste(xG[,1]), col=rainbow(rainbowColor) )
    legend("topright", legend=paste(xG[,1]), fill=rainbow(rainbowColor))
  })
})